import MainApp from "./src/views/MainApp";

function App() {
  return <MainApp />;
}

export default App;
