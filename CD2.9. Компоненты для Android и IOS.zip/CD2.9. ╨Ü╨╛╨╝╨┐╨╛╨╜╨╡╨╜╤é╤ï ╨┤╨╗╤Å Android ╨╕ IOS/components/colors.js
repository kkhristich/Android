export const COLORS = {
  primary: "#00b0ff",
  primaryLight: "#69e2ff",
  primaryDark: "#0081cb",
  secondary: "#00e676",
  secondaryLight: "#66ffa6",
  secondaryDark: "#00b248",
  textOnPrimary: "#000000",
  textOnSecondary: "#000000",
  white: "#fff",
  black: "#000",
  gray: "#777",
};
